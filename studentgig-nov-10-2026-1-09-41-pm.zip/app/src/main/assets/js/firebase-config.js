// Firebase Configuration for StudentGig
// Firebase Project: studentgig11

const firebaseConfig = {
  apiKey: "AIzaSyAI6TCImLnLg-AUTxCxudsrDiSetUPeAdE",
  authDomain: "studentgig11.firebaseapp.com",
  projectId: "studentgig11",
  storageBucket: "studentgig11.firebasestorage.app",
  messagingSenderId: "282730104035",
  appId: "1:282730104035:web:b3c87e244136a55924f1d6"
};

// Initialize Firebase
let app, auth, db, storage;

try {
  if (typeof firebase !== 'undefined') {
    if (!firebase.apps.length) {
      app = firebase.initializeApp(firebaseConfig);
    } else {
      app = firebase.app();
    }
    auth = firebase.auth();
    db = firebase.firestore();
    
    // Enable offline persistence where supported
    db.enablePersistence({ synchronizeTabs: true }).catch(err => {
      console.warn("Firestore persistence notice:", err.code);
    });

    try {
      storage = firebase.storage();
    } catch (e) {
      console.warn("Firebase storage init notice:", e);
    }
    console.log("StudentGig Firebase Initialized: project studentgig11");
  } else {
    console.warn("Firebase SDK script not loaded yet");
  }
} catch (error) {
  console.error("Firebase Initialization Error:", error);
}

// Utility: Format Currency in Nigerian Naira (₦)
function formatNaira(amount) {
  const num = Number(amount) || 0;
  return "₦" + num.toLocaleString("en-NG", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

// Utility: Format Date
function formatDate(timestamp) {
  if (!timestamp) return "Recently";
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleDateString("en-NG", { month: "short", day: "numeric", year: "numeric" });
}

// Utility: Format Relative Time
function formatTimeAgo(timestamp) {
  if (!timestamp) return "Just now";
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
  if (diffSec < 60) return "Just now";
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  return `${Math.floor(diffSec / 86400)}d ago`;
}
