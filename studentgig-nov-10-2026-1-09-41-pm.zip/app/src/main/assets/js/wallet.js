// Wallet & Financial Ledger Controller for StudentGig

async function initWalletPage() {
  Auth.requireAuth("login.html");

  Auth.init(async (user, profile) => {
    if (!user) return;

    // Listen to real-time wallet balances
    DB.listenWallet(user.uid, (wallet) => {
      document.getElementById("walletAvailable").textContent = formatNaira(wallet.availableBalance || 0);
      document.getElementById("walletPending").textContent = formatNaira(wallet.pendingBalance || 0);
      document.getElementById("walletEarnings").textContent = formatNaira(wallet.totalEarnings || 0);
    });

    // Load user transaction history
    await loadUserTransactions(user.uid);
  });
}

async function loadUserTransactions(userId) {
  const container = document.getElementById("walletTransactionsList");
  if (!container) return;

  container.innerHTML = `
    <div class="loading-container">
      <div class="spinner"></div>
      <div>Loading ledger history...</div>
    </div>
  `;

  try {
    const transactions = await DB.getUserTransactions(userId);
    if (transactions.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">💳</div>
          <div class="empty-title">No transactions yet</div>
          <div class="empty-desc">Your approved deposits, gig earnings, and withdrawals will be recorded here securely.</div>
          <a href="payments.html" class="btn btn-primary btn-sm">Make a Moniepoint Deposit</a>
        </div>
      `;
      return;
    }

    container.innerHTML = transactions.map(t => {
      const isCredit = t.type === 'deposit' || t.type === 'earning';
      const color = isCredit ? 'var(--primary)' : 'var(--danger)';
      const sign = isCredit ? '+' : '-';

      return `
        <div class="card" style="padding: 14px 16px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 38px; height: 38px; border-radius: 50%; background: ${isCredit ? 'var(--primary-light)' : 'var(--danger-light)'}; color: ${color}; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
              ${isCredit ? '↓' : '↑'}
            </div>
            <div>
              <div style="font-weight: 700; color: var(--secondary); font-size: 0.95rem;">${t.description || 'Transaction'}</div>
              <div style="font-size: 0.78rem; color: var(--text-muted);">${formatDate(t.createdAt)} • Ref: ${t.reference || 'N/A'}</div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-weight: 800; font-size: 1.05rem; color: ${color};">${sign}${formatNaira(t.amount)}</div>
            <span class="badge ${t.status === 'completed' ? 'badge-approved' : 'badge-pending'}">${t.status}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Error loading transactions.</div>`;
  }
}

// Withdrawal Request Modal
function openWithdrawalModal() {
  const modal = document.getElementById("withdrawModal");
  if (modal) modal.classList.add("active");
}

function closeWithdrawalModal() {
  const modal = document.getElementById("withdrawModal");
  if (modal) modal.classList.remove("active");
}

async function handleWithdrawalSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("submitWithdrawBtn");
  const alertBox = document.getElementById("withdrawAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  if (!user) return;

  const amount = Number(document.getElementById("withdrawAmount").value);
  const bankName = document.getElementById("withdrawBankName").value.trim();
  const accountNumber = document.getElementById("withdrawAccountNumber").value.trim();
  const accountName = document.getElementById("withdrawAccountName").value.trim();

  // Validate current balance
  const wallet = await DB.getWallet(user.uid);
  if (amount > (wallet.availableBalance || 0)) {
    alertBox.innerHTML = `<div class="alert alert-error">Insufficient available balance. You have ${formatNaira(wallet.availableBalance || 0)}.</div>`;
    return;
  }
  if (amount < 1000) {
    alertBox.innerHTML = `<div class="alert alert-error">Minimum withdrawal amount is ₦1,000.</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Submitting Request...`;

  try {
    // Save withdrawal request for admin manual disbursement
    await db.collection("withdrawal_requests").add({
      userId: user.uid,
      userName: Auth.userProfile?.fullName || user.displayName || "User",
      userEmail: user.email,
      amount: amount,
      bankName: bankName,
      accountNumber: accountNumber,
      accountName: accountName,
      status: "pending",
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // Debit available, move to pending
    await db.collection(DB.WALLETS).doc(user.uid).update({
      availableBalance: firebase.firestore.FieldValue.increment(-amount),
      pendingBalance: firebase.firestore.FieldValue.increment(amount)
    });

    // Ledger transaction
    await db.collection(DB.TRANSACTIONS).add({
      userId: user.uid,
      type: "withdrawal",
      amount: amount,
      status: "pending",
      description: `Withdrawal request to ${bankName} (${accountNumber})`,
      reference: `WTH-${Date.now().toString().slice(-6)}`,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    alertBox.innerHTML = `<div class="alert alert-success">Withdrawal request placed. Admin will process disbursement to your bank account within 24-48 hours.</div>`;
    setTimeout(() => {
      closeWithdrawalModal();
      btn.disabled = false;
      btn.innerHTML = "Request Payout";
    }, 1800);
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Failed: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = "Request Payout";
  }
}
