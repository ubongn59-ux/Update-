// Notifications Controller for StudentGig

async function initNotificationsPage() {
  Auth.requireAuth("login.html");

  Auth.init(async (user) => {
    if (!user) return;
    loadNotifications(user.uid);
  });
}

function loadNotifications(userId) {
  const container = document.getElementById("notificationsListContainer");
  if (!container) return;

  container.innerHTML = `
    <div class="loading-container">
      <div class="spinner"></div>
      <div>Loading notifications...</div>
    </div>
  `;

  DB.listenNotifications(userId, (notifs) => {
    if (notifs.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🔔</div>
          <div class="empty-title">All caught up</div>
          <div class="empty-desc">You have no new notifications right now. Updates on payments, orders, and messages will appear here.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = notifs.map(n => {
      let icon = "🔔";
      if (n.type?.includes("payment")) icon = "💳";
      if (n.type?.includes("message")) icon = "💬";
      if (n.type?.includes("proposal")) icon = "💼";
      if (n.type?.includes("order")) icon = "📦";

      return `
        <div class="card card-hover" style="margin-bottom: 10px; padding: 14px 16px; border-left: 4px solid ${n.read ? 'var(--border)' : 'var(--primary)'}; background: ${n.read ? 'white' : 'var(--primary-light)'}; cursor: pointer;" onclick="handleNotificationClick('${n.id}', '${n.link || ''}')">
          <div style="display: flex; align-items: flex-start; gap: 12px;">
            <div style="font-size: 1.4rem;">${icon}</div>
            <div style="flex: 1;">
              <div style="display: flex; justify-content: space-between; align-items: baseline;">
                <div style="font-weight: 700; color: var(--secondary); font-size: 0.95rem;">${n.title}</div>
                <div style="font-size: 0.72rem; color: var(--text-muted);">${formatTimeAgo(n.createdAt)}</div>
              </div>
              <div style="font-size: 0.86rem; color: var(--text-main); margin-top: 3px;">${n.message}</div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  });
}

async function handleNotificationClick(notifId, link) {
  try {
    await DB.markNotificationRead(notifId);
  } catch (e) {}
  if (link && link !== '') {
    window.location.href = link;
  }
}
