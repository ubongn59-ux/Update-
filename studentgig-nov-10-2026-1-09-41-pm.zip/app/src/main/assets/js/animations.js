// StudentGig Animation and Interactive Polish Utility

// 1. Splash Screen Initialization
function initSplashScreen(autoDismissMs = 600) {
  let splash = document.getElementById("appSplashScreen");
  if (!splash) {
    splash = document.createElement("div");
    splash.id = "appSplashScreen";
    splash.innerHTML = `
      <div class="splash-logo-container">
        <div class="splash-logo-icon">⚡</div>
        <div class="splash-title">Student<span>Gig</span></div>
        <div class="splash-sub">Nigerian Student Freelance Marketplace</div>
      </div>
    `;
    document.body.prepend(splash);
  }

  // Dismiss smoothly after initial paint
  window.addEventListener("load", () => {
    setTimeout(() => {
      splash.classList.add("hidden");
      setTimeout(() => splash.remove(), 400);
    }, autoDismissMs);
  });
}

// 2. Animate Number Counting (e.g. Wallet Balance: ₦0 -> ₦50,000)
function animateValue(element, start, end, duration = 800, prefix = "₦") {
  if (!element) return;
  const startTime = performance.now();
  const startNum = Number(start) || 0;
  const endNum = Number(end) || 0;

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease-out cubic
    const easeProgress = 1 - Math.pow(1 - progress, 3);
    const current = Math.floor(startNum + (endNum - startNum) * easeProgress);

    element.textContent = `${prefix}${current.toLocaleString("en-NG")}`;

    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      element.textContent = `${prefix}${endNum.toLocaleString("en-NG")}`;
    }
  }

  requestAnimationFrame(update);
}

// 3. Animated Toast Pop-Up Notifications
function showToast(message, type = "info", duration = 3000) {
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast-message toast-${type}`;
  let icon = "💡";
  if (type === "success") icon = "✓";
  if (type === "error") icon = "⚠️";

  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("toast-out");
    setTimeout(() => toast.remove(), 250);
  }, duration);
}

// 4. Render Payment Success Animated Checkmark
function renderSuccessCheckmark(containerEl) {
  if (!containerEl) return;
  containerEl.innerHTML = `
    <div class="checkmark-wrapper">
      <svg class="checkmark-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
        <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
        <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
      </svg>
    </div>
  `;
}

// Initialize splash automatically if on mobile view
if (!window.sessionStorage.getItem("sg_splash_shown")) {
  initSplashScreen(750);
  window.sessionStorage.setItem("sg_splash_shown", "true");
}
