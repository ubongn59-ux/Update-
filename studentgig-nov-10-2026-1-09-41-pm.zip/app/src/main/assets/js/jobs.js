// Job Posting and Proposal System for StudentGig

let allJobsCache = [];

async function initJobsPage() {
  await loadAvailableJobs();

  const searchInput = document.getElementById("jobSearchInput");
  if (searchInput) {
    searchInput.addEventListener("input", debounce(() => {
      filterAndRenderJobs();
    }, 300));
  }

  const catFilter = document.getElementById("jobCategoryFilter");
  if (catFilter) {
    catFilter.addEventListener("change", () => {
      filterAndRenderJobs();
    });
  }
}

async function loadAvailableJobs() {
  const container = document.getElementById("jobsListContainer");
  if (!container) return;

  container.innerHTML = `
    <div class="loading-container">
      <div class="spinner"></div>
      <div>Loading available client jobs...</div>
    </div>
  `;

  try {
    allJobsCache = await DB.getJobs();
    filterAndRenderJobs();
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Failed to load jobs list.</div>`;
  }
}

function filterAndRenderJobs() {
  const container = document.getElementById("jobsListContainer");
  if (!container) return;

  const searchVal = document.getElementById("jobSearchInput")?.value?.toLowerCase().trim() || "";
  const catVal = document.getElementById("jobCategoryFilter")?.value || "All";

  let filtered = [...allJobsCache];

  if (catVal !== "All") {
    filtered = filtered.filter(j => j.category === catVal);
  }

  if (searchVal) {
    filtered = filtered.filter(j => 
      (j.title && j.title.toLowerCase().includes(searchVal)) ||
      (j.description && j.description.toLowerCase().includes(searchVal)) ||
      (j.category && j.category.toLowerCase().includes(searchVal))
    );
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💼</div>
        <div class="empty-title">No client jobs found</div>
        <div class="empty-desc">There are no open projects matching your search. Post a job if you need help!</div>
        <a href="post-job.html" class="btn btn-primary btn-sm">Post a Job</a>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(job => `
    <div class="job-card">
      <div class="job-header-row">
        <div>
          <span class="badge badge-category" style="margin-bottom: 6px;">${job.category || 'General'}</span>
          <h3 class="job-title">${job.title}</h3>
        </div>
        <div class="job-budget">${formatNaira(job.budget)}</div>
      </div>
      <p class="job-desc">${job.description}</p>
      
      ${job.skills && job.skills.length > 0 ? `
        <div class="skills-tags">
          ${job.skills.map(s => `<span class="skill-tag">${s}</span>`).join('')}
        </div>
      ` : ''}

      <div class="job-meta-row">
        <span>Posted by @${job.clientName || 'client'} • ${formatTimeAgo(job.createdAt)}</span>
        <button class="btn btn-primary btn-sm" onclick="openProposalModal('${job.id}', '${encodeURIComponent(job.title)}', ${job.budget})">
          Send Proposal
        </button>
      </div>
    </div>
  `).join('');
}

// Handle Client Job Posting Form
async function handlePostJobSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("postJobSubmitBtn");
  const alertBox = document.getElementById("postJobAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  const profile = Auth.userProfile;
  if (!user) {
    alert("Please log in to publish a job.");
    window.location.href = "login.html";
    return;
  }

  const title = document.getElementById("jobTitle").value.trim();
  const category = document.getElementById("jobCategory").value;
  const description = document.getElementById("jobDescription").value.trim();
  const budget = Number(document.getElementById("jobBudget").value);
  const deadline = document.getElementById("jobDeadline").value;
  const skillsInput = document.getElementById("jobSkills").value;

  if (!title || title.length < 5) {
    alertBox.innerHTML = `<div class="alert alert-error">Job title must be at least 5 characters.</div>`;
    return;
  }
  if (!budget || budget < 1000) {
    alertBox.innerHTML = `<div class="alert alert-error">Minimum job budget is ₦1,000.</div>`;
    return;
  }

  const skills = skillsInput ? skillsInput.split(',').map(s => s.trim()).filter(Boolean) : [];

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Publishing Job...`;

  try {
    const jobData = {
      clientId: user.uid,
      clientName: profile?.username || user.displayName || "client",
      clientAvatar: profile?.avatarUrl || "",
      title: title,
      category: category,
      description: description,
      budget: budget,
      deadline: deadline || "Flexible",
      skills: skills
    };

    await DB.createJob(jobData);
    alertBox.innerHTML = `<div class="alert alert-success">Job published successfully! Redirecting...</div>`;
    setTimeout(() => {
      window.location.href = "jobs.html";
    }, 1200);
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Failed to post job: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = `Post Job`;
  }
}

// Modal Proposal Submission
function openProposalModal(jobId, encodedTitle, budget) {
  const user = Auth.currentUser;
  if (!user) {
    alert("Please login to submit proposals.");
    window.location.href = "login.html";
    return;
  }

  const modal = document.getElementById("proposalModal");
  const titleEl = document.getElementById("modalJobTitle");
  const jobIdInput = document.getElementById("proposalJobId");
  const priceInput = document.getElementById("proposalPrice");

  if (titleEl) titleEl.textContent = decodeURIComponent(encodedTitle);
  if (jobIdInput) jobIdInput.value = jobId;
  if (priceInput) priceInput.value = budget || "";

  if (modal) modal.classList.add("active");
}

function closeProposalModal() {
  const modal = document.getElementById("proposalModal");
  if (modal) modal.classList.remove("active");
}

async function handleProposalSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("submitProposalBtn");
  const alertBox = document.getElementById("proposalAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  const profile = Auth.userProfile;
  if (!user) return;

  const jobId = document.getElementById("proposalJobId").value;
  const proposedPrice = Number(document.getElementById("proposalPrice").value);
  const deliveryDays = Number(document.getElementById("proposalDeliveryDays").value);
  const coverLetter = document.getElementById("proposalLetter").value.trim();

  if (!proposedPrice || proposedPrice < 500) {
    alertBox.innerHTML = `<div class="alert alert-error">Please enter a valid price (min ₦500).</div>`;
    return;
  }
  if (!coverLetter || coverLetter.length < 10) {
    alertBox.innerHTML = `<div class="alert alert-error">Please write a brief pitch explaining your skills (min 10 chars).</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Sending...`;

  try {
    const proposalData = {
      jobId: jobId,
      jobTitle: document.getElementById("modalJobTitle").textContent,
      freelancerId: user.uid,
      freelancerName: profile?.username || user.displayName || "freelancer",
      freelancerAvatar: profile?.avatarUrl || "",
      proposedPrice: proposedPrice,
      deliveryDays: deliveryDays || 2,
      coverLetter: coverLetter
    };

    await DB.submitProposal(proposalData);
    alertBox.innerHTML = `<div class="alert alert-success">Proposal submitted! The client has been notified.</div>`;
    setTimeout(() => {
      closeProposalModal();
      btn.disabled = false;
      btn.innerHTML = "Submit Proposal";
    }, 1500);
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Error submitting: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = "Submit Proposal";
  }
}
