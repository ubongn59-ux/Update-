// Administrator Payment Review & Verification Management Module

let currentFilter = "All";
let cachedAdminPayments = [];
let activeReviewCountdownInterval = null;

async function initAdminPaymentsPage() {
  AdminAuth.requireAdminAuth("admin-login.html");

  window.addEventListener('adminReady', async () => {
    await loadAdminPayments();
  });

  // Filter tabs listener
  document.querySelectorAll(".admin-pay-filter").forEach(btn => {
    btn.addEventListener("click", (e) => {
      document.querySelectorAll(".admin-pay-filter").forEach(b => b.classList.remove("active"));
      e.target.classList.add("active");
      currentFilter = e.target.getAttribute("data-filter");
      renderAdminPaymentsTable();
    });
  });
}

async function loadAdminPayments() {
  const tableBody = document.getElementById("adminPaymentsTableBody");
  if (!tableBody) return;

  tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:24px;color:#94a3b8;"><div class="spinner"></div></td></tr>`;

  try {
    cachedAdminPayments = await DB.getAdminPayments();
    updatePaymentCounters();
    renderAdminPaymentsTable();
  } catch (err) {
    tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#ef4444;padding:20px;">Failed to load payments: ${err.message}</td></tr>`;
  }
}

function updatePaymentCounters() {
  const total = cachedAdminPayments.length;
  const pending = cachedAdminPayments.filter(p => p.status === 'Pending Review');
  const approved = cachedAdminPayments.filter(p => p.status === 'Approved').length;
  const rejected = cachedAdminPayments.filter(p => p.status === 'Rejected').length;

  const now = Date.now();
  const overdue = pending.filter(p => {
    const d = p.reviewDeadline?.toDate ? p.reviewDeadline.toDate() : new Date(p.reviewDeadline);
    return d && d.getTime() < now;
  }).length;

  setStat("countTotalPay", total);
  setStat("countPendingPay", pending.length);
  setStat("countApprovedPay", approved);
  setStat("countRejectedPay", rejected);
  setStat("countOverduePay", overdue);
}

function renderAdminPaymentsTable() {
  const tableBody = document.getElementById("adminPaymentsTableBody");
  if (!tableBody) return;

  let list = [...cachedAdminPayments];
  const now = Date.now();

  if (currentFilter === "Pending") {
    list = list.filter(p => p.status === 'Pending Review');
  } else if (currentFilter === "Approved") {
    list = list.filter(p => p.status === 'Approved');
  } else if (currentFilter === "Rejected") {
    list = list.filter(p => p.status === 'Rejected');
  } else if (currentFilter === "Overdue") {
    list = list.filter(p => {
      const d = p.reviewDeadline?.toDate ? p.reviewDeadline.toDate() : new Date(p.reviewDeadline);
      return p.status === 'Pending Review' && d && d.getTime() < now;
    });
  }

  if (list.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:32px;color:#94a3b8;">No payment records in this category.</td></tr>`;
    return;
  }

  tableBody.innerHTML = list.map(p => {
    const isPending = p.status === 'Pending Review';
    const deadline = p.reviewDeadline?.toDate ? p.reviewDeadline.toDate() : new Date(p.reviewDeadline);
    const isOverdue = isPending && deadline && deadline.getTime() < now;

    let badge = `<span class="badge badge-pending">Pending Review</span>`;
    if (p.status === 'Approved') badge = `<span class="badge badge-approved">Approved</span>`;
    if (p.status === 'Rejected') badge = `<span class="badge badge-rejected">Rejected</span>`;
    if (isOverdue) badge = `<span class="badge badge-overdue">24h Overdue</span>`;

    return `
      <tr>
        <td>
          <img src="${p.screenshotUrl || 'https://via.placeholder.com/100?text=Receipt'}" class="screenshot-thumb" onclick="openScreenshotModal('${p.screenshotUrl}')" alt="Receipt">
        </td>
        <td>
          <div style="font-weight:700;color:#fff;">${formatNaira(p.amount)}</div>
          <div style="font-size:0.75rem;color:#94a3b8;">Ref: ${p.transactionRef}</div>
        </td>
        <td>
          <div style="font-weight:600;">${p.payerName}</div>
          <div style="font-size:0.75rem;color:#94a3b8;">${p.userName} (${p.userEmail || ''})</div>
        </td>
        <td>
          <div style="font-size:0.82rem;">${formatDate(p.createdAt)}</div>
          ${isPending ? `
            <div class="admin-countdown-ticker" data-target="${deadline?.getTime() || 0}" style="font-size:0.72rem;color:${isOverdue ? '#ef4444' : '#f59e0b'};font-weight:700;">
              Calculating...
            </div>
          ` : `
            <div style="font-size:0.72rem;color:#94a3b8;">Reviewed by: ${p.reviewedBy || 'Admin'}</div>
          `}
        </td>
        <td>${badge}</td>
        <td>
          ${isPending ? `
            <div style="display:flex;gap:6px;">
              <button class="btn btn-primary btn-sm" onclick="handleApprovePaymentClick('${p.id}')">Approve</button>
              <button class="btn btn-danger btn-sm" onclick="openRejectModal('${p.id}', '${p.userName}', ${p.amount})">Reject</button>
            </div>
          ` : `
            <span style="font-size:0.8rem;color:#94a3b8;">Done</span>
          `}
        </td>
      </tr>
    `;
  }).join('');

  startAdminCountdownTickers();
}

function startAdminCountdownTickers() {
  if (activeReviewCountdownInterval) clearInterval(activeReviewCountdownInterval);

  function tick() {
    document.querySelectorAll(".admin-countdown-ticker").forEach(el => {
      const target = Number(el.getAttribute("data-target"));
      if (!target) return;
      const diff = target - Date.now();
      if (diff <= 0) {
        el.textContent = "OVERDUE (>24h)";
        el.style.color = "#ef4444";
      } else {
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        el.textContent = `${h}h ${m}m ${s}s target`;
      }
    });
  }
  tick();
  activeReviewCountdownInterval = setInterval(tick, 1000);
}

// Screenshot Inspection Lightbox
function openScreenshotModal(url) {
  const modal = document.getElementById("adminScreenshotModal");
  const img = document.getElementById("adminModalScreenshotImg");
  if (img) img.src = url;
  if (modal) modal.classList.add("active");
}

function closeScreenshotModal() {
  const modal = document.getElementById("adminScreenshotModal");
  if (modal) modal.classList.remove("active");
}

// Approve Payment Action
async function handleApprovePaymentClick(paymentId) {
  const p = cachedAdminPayments.find(item => item.id === paymentId);
  if (!p) return;

  const confirmed = confirm(`Are you sure you have confirmed receipt of ${formatNaira(p.amount)} from ${p.payerName} (Ref: ${p.transactionRef}) in your official Moniepoint account?\n\nApproving will immediately credit ${p.userName}'s wallet.`);
  if (!confirmed) return;

  try {
    const adminEmail = AdminAuth.currentAdmin?.email || "admin@studentgig.ng";
    await DB.approvePayment(paymentId, adminEmail);
    alert("Payment approved successfully! User wallet credited and notified.");
    await loadAdminPayments();
  } catch (err) {
    alert("Error approving payment: " + err.message);
  }
}

// Reject Payment Action with Mandatory Reason
let currentRejectPaymentId = null;

function openRejectModal(paymentId, userName, amount) {
  currentRejectPaymentId = paymentId;
  const modal = document.getElementById("adminRejectModal");
  const infoEl = document.getElementById("rejectPaymentInfo");
  if (infoEl) infoEl.textContent = `Rejecting ${formatNaira(amount)} submission from ${userName}`;
  if (modal) modal.classList.add("active");
}

function closeRejectModal() {
  currentRejectPaymentId = null;
  const modal = document.getElementById("adminRejectModal");
  if (modal) modal.classList.remove("active");
}

async function handleConfirmRejectSubmit(e) {
  e.preventDefault();
  if (!currentRejectPaymentId) return;

  const reason = document.getElementById("adminRejectionReason").value.trim();
  if (!reason) {
    alert("A rejection reason is mandatory so the student knows why their submission was declined.");
    return;
  }

  const btn = document.getElementById("adminConfirmRejectBtn");
  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Rejecting...`;

  try {
    const adminEmail = AdminAuth.currentAdmin?.email || "admin@studentgig.ng";
    await DB.rejectPayment(currentRejectPaymentId, reason, adminEmail);
    alert("Payment rejected. Notification dispatched with the specified reason.");
    closeRejectModal();
    btn.disabled = false;
    btn.innerHTML = "Confirm Rejection";
    await loadAdminPayments();
  } catch (err) {
    alert("Error rejecting payment: " + err.message);
    btn.disabled = false;
    btn.innerHTML = "Confirm Rejection";
  }
}
