// User Profile & Portfolio Management Controller for StudentGig

async function initProfilePage() {
  Auth.requireAuth("login.html");

  Auth.init(async (user, profile) => {
    if (!user) return;
    renderProfileView(user, profile);
  });
}

function renderProfileView(user, profile) {
  // Populate View Fields
  const nameEl = document.getElementById("profileFullName");
  const usernameEl = document.getElementById("profileUsername");
  const avatarEl = document.getElementById("profileAvatar");
  const bioEl = document.getElementById("profileBio");
  const locationEl = document.getElementById("profileLocation");
  const ratingEl = document.getElementById("profileRating");
  const jobsCountEl = document.getElementById("profileCompletedJobs");
  const memberSinceEl = document.getElementById("profileMemberSince");
  const skillsContainer = document.getElementById("profileSkillsContainer");

  if (nameEl) nameEl.textContent = profile?.fullName || user.displayName || "Student User";
  if (usernameEl) usernameEl.textContent = `@${profile?.username || 'user'}`;
  if (avatarEl) {
    avatarEl.src = profile?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username || 'user'}`;
  }
  if (bioEl) bioEl.textContent = profile?.bio || "No biography provided yet.";
  if (locationEl) locationEl.textContent = profile?.location || "Nigeria";
  if (ratingEl) ratingEl.textContent = Number(profile?.rating || 5.0).toFixed(1);
  if (jobsCountEl) jobsCountEl.textContent = profile?.completedJobs || 0;
  if (memberSinceEl) memberSinceEl.textContent = formatDate(profile?.createdAt || user.metadata.creationTime);

  // Skills
  if (skillsContainer) {
    if (profile?.skills && profile.skills.length > 0) {
      skillsContainer.innerHTML = profile.skills.map(s => `<span class="skill-tag">${s}</span>`).join('');
    } else {
      skillsContainer.innerHTML = `<span style="color:var(--text-muted);font-size:0.85rem;">No skills listed. Click Edit Profile to add skills.</span>`;
    }
  }

  // Pre-fill Edit Modal Fields
  const editName = document.getElementById("editFullName");
  const editBio = document.getElementById("editBio");
  const editSkills = document.getElementById("editSkills");
  const editLocation = document.getElementById("editLocation");

  if (editName) editName.value = profile?.fullName || "";
  if (editBio) editBio.value = profile?.bio || "";
  if (editSkills) editSkills.value = (profile?.skills || []).join(', ');
  if (editLocation) editLocation.value = profile?.location || "Nigeria";
}

function openEditProfileModal() {
  const modal = document.getElementById("editProfileModal");
  if (modal) modal.classList.add("active");
}

function closeEditProfileModal() {
  const modal = document.getElementById("editProfileModal");
  if (modal) modal.classList.remove("active");
}

async function handleProfileUpdateSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById("saveProfileBtn");
  const alertBox = document.getElementById("editProfileAlert");
  alertBox.innerHTML = "";

  const user = Auth.currentUser;
  if (!user) return;

  const fullName = document.getElementById("editFullName").value.trim();
  const bio = document.getElementById("editBio").value.trim();
  const skillsStr = document.getElementById("editSkills").value.trim();
  const location = document.getElementById("editLocation").value.trim();
  const avatarInput = document.getElementById("editAvatarInput");

  if (!fullName) {
    alertBox.innerHTML = `<div class="alert alert-error">Full name cannot be empty.</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<div class="spinner spinner-sm"></div> Saving...`;

  try {
    let avatarUrl = Auth.userProfile?.avatarUrl;
    if (avatarInput && avatarInput.files && avatarInput.files[0]) {
      avatarUrl = await readFileAsDataURL(avatarInput.files[0]);
    }

    const skills = skillsStr ? skillsStr.split(',').map(s => s.trim()).filter(Boolean) : [];

    const updatedData = {
      fullName: fullName,
      bio: bio,
      skills: skills,
      location: location || "Nigeria",
      avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${Auth.userProfile?.username || 'user'}`
    };

    await DB.updateUser(user.uid, updatedData);
    Auth.userProfile = { ...Auth.userProfile, ...updatedData };
    renderProfileView(user, Auth.userProfile);

    alertBox.innerHTML = `<div class="alert alert-success">Profile updated successfully!</div>`;
    setTimeout(() => {
      closeEditProfileModal();
      btn.disabled = false;
      btn.innerHTML = "Save Changes";
    }, 1200);
  } catch (err) {
    alertBox.innerHTML = `<div class="alert alert-error">Failed: ${err.message}</div>`;
    btn.disabled = false;
    btn.innerHTML = "Save Changes";
  }
}
